/**
 * Displays the add contact buttons (large and small) on the page.
 */
function displayAddContactButtons() {
    if (document.getElementById('show-overlay') || document.getElementById('add-contact-icon')) {
        return;
    }

    let contactList = document.querySelector('.contact-list');
    if (!contactList) {
        console.error("Contact list container not found.");
        return;
    }

    let addButtonLarge = generateAddButtonLargeHTML();
    let addButtonSmall = generateAddButtonSmallHTML();

    contactList.insertAdjacentHTML('afterbegin', addButtonLarge);
    document.body.insertAdjacentHTML('beforeend', addButtonSmall);

    attachAddContactButtonListeners();
}


/**
* Generates the HTML for the large add contact button.
* @returns {string} - HTML string for the large add contact button.
*/
function generateAddButtonLargeHTML() {
    return `
        <div class="add-contact-button" id="show-overlay">
            <span>Add New Contact</span>
            <img src="../Assets/personAdd.svg" alt="Add Contact" class="add-icon" />
        </div>`;
 }
 
 
 /**
 * Generates the HTML for the small add contact button.
 * @returns {string} - HTML string for the small add contact button.
 */
 function generateAddButtonSmallHTML() {
    return `
        <div class="add-contact-icon" id="add-contact-icon">
            <img src="../Assets/personAdd.svg" alt="Add Contact">
        </div>`;
 }


/**
 * Displays contact details and adjusts the UI for smaller screens if needed.
 * @param {string} contactId - The ID of the contact to display.
 */
function showContactDetails(contactId) {
    let contact = contacts.find(c => c.id === contactId);
    if (!contact) return;

    currentContactId = contact.id;
    updateContactDetailsUI(contact);
    handleSmallScreenAdjustments();
    attachEditAndDeleteListeners(contactId, contact);
}


/**
 * Updates the contact details UI with the provided contact data.
 * @param {object} contact - The contact object to display.
 */
function updateContactDetailsUI(contact) {
    document.getElementById('contact-name').textContent = contact.name;
    document.getElementById('contact-email').textContent = contact.email;
    document.getElementById('contact-phone').textContent = contact.phone;
    document.getElementById('contact-initials').textContent = getInitials(contact.name);
    document.getElementById('contact-initials').style.backgroundColor = contact.color;
    document.getElementById('contact-details').style.display = 'block';
}


/**
 * Adjusts the UI for smaller screens and attaches relevant listeners.
 */
function handleSmallScreenAdjustments() {
    if (window.innerWidth > 780) return;

    let contactList = document.querySelector('.contact-list');
    let contactDetails = document.querySelector('.contact');
    let backArrow = document.getElementById('back-arrow');
    let addContactIcon = document.getElementById('add-contact-icon');
    let dotsIcon = document.getElementById('dots-icon');
    let smallOverlay = document.getElementById('small-overlay');

    toggleSmallScreenUI(contactList, contactDetails, backArrow, addContactIcon, dotsIcon, smallOverlay);
}


/**
 * Toggles the UI elements for smaller screens.
 */
function toggleSmallScreenUI(contactList, contactDetails, backArrow, addContactIcon, dotsIcon, smallOverlay) {
    contactList.style.display = 'none';
    contactDetails.style.display = 'flex';
    backArrow.style.display = 'block';
    addContactIcon.style.display = 'none';
    if (dotsIcon) dotsIcon.style.display = 'flex';

    backArrow.onclick = () => resetSmallScreenUI(contactList, contactDetails, backArrow, addContactIcon, dotsIcon, smallOverlay);
    attachDotsIconListener(dotsIcon, smallOverlay);
}


/**
 * Resets the UI elements to their default state for small screens.
 */
function resetSmallScreenUI(contactList, contactDetails, backArrow, addContactIcon, dotsIcon, smallOverlay) {
    contactList.style.display = 'block';
    contactDetails.style.display = 'none';
    backArrow.style.display = 'none';
    addContactIcon.style.display = 'block';
    if (dotsIcon) dotsIcon.style.display = 'none';
    if (smallOverlay) smallOverlay.style.display = 'none';
}


/**
 * Attaches the click listener to the dots icon to toggle the small overlay.
 */
function attachDotsIconListener(dotsIcon, smallOverlay) {
    if (!dotsIcon) return;

    dotsIcon.onclick = (event) => {
        event.stopPropagation();
        if (smallOverlay) {
            smallOverlay.style.display = smallOverlay.style.display === 'block' || smallOverlay.style.display === '' 
                ? 'none' 
                : 'flex';
        }
    };
}


/**
 * Attaches edit and delete listeners to the respective buttons.
 * @param {string} contactId - The ID of the contact to edit or delete.
 * @param {object} contact - The contact object.
 */
function attachEditAndDeleteListeners(contactId, contact) {
    let editLink = document.querySelector('.edit-link');
    let deleteLink = document.querySelector('.delete-link');
    let initialsColor = getRandomColor();

    if (editLink) {
        editLink.addEventListener('click', function (event) {
            event.preventDefault();
            openEditOverlay(contact, initialsColor);
        });
    }

    if (deleteLink) {
        deleteLink.addEventListener('click', function (event) {
            event.preventDefault();
            deleteContact(contactId);
        });
    }
}


// Event listener for back arrow click
document.getElementById('back-arrow')?.addEventListener('click', handleBackArrowClick);


/**
 * Handles the back arrow click to reset the view for small screens.
 */
function handleBackArrowClick() {
    if (window.innerWidth <= 780) {
        toggleElementVisibility('.contact-list', true);
        toggleElementVisibility('.contact', false);
    }
    toggleElementVisibility('#dots-icon', false);
    toggleElementVisibility('#add-contact-icon', true);
}


/**
 * Clears the contact details section.
 */
function clearContactDetails() {
    updateElementContent('#contact-name', '');
    updateElementContent('#contact-email', '');
    updateElementContent('#contact-phone', '');
    updateElementContent('#contact-initials', '');
    setElementBackgroundColor('#contact-initials', '');
    toggleElementVisibility('#contact-details', false);
}


/**
 * Updates the contact details section with the updated contact information.
 * @param {object} contact - The updated contact object.
 */
function updateContactDetailsSection(contact) {
    updateElementContent('#contact-name', contact.name);
    updateElementContent('#contact-email', contact.email);
    updateElementContent('#contact-phone', contact.phone);
    updateElementContent('#contact-initials', getInitials(contact.name));
    setElementBackgroundColor('#contact-initials', getRandomColor());
}


/**
 * Resets the contact view to show the contact list.
 */
function resetContactView() {
    toggleElementVisibility('.contact', false);
    toggleElementVisibility('.contact-list', true);
}


/**
 * Opens the overlay and populates input fields with contact details and initials.
 * @param {object} contact - Contact object containing the details.
 */
function openEditOverlay(contact) {
    toggleElementVisibility('#contact-overlay', true);
    currentContactId = contact.id;

    updateElementContent('#edit-contact-name', contact.name);
    updateElementContent('#edit-contact-email', contact.email);
    updateElementContent('#edit-contact-phone', contact.phone);
    updateElementContent('#contact-initials-overlay', getInitials(contact.name));
    setElementBackgroundColor('#contact-initials-overlay', contact.color);
}


// Close overlay event listener
document.getElementById('close-contact-overlay')?.addEventListener('click', (event) => {
    event.preventDefault();
    toggleElementVisibility('#contact-overlay', false);
});


// Delete contact button event listener
document.getElementById('delete-contact-button')?.addEventListener('click', () => {
    if (currentContactId) deleteContact(currentContactId);
});


// Event listeners for global actions
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('back-arrow')?.addEventListener('click', handleBackArrowClick);
    loadContacts();
    attachGlobalEventListeners();
    displayContacts();
    displayAddContactButtons();
});


/**
 * Attaches global event listeners for actions like back arrow and overlays.
 */
function attachGlobalEventListeners() {
    document.getElementById('dots-icon')?.addEventListener('click', toggleSmallOverlay);
    document.getElementById('close-contact-overlay')?.addEventListener('click', closeContactOverlay);
    document.getElementById('delete-contact-button')?.addEventListener('click', handleDeleteContact);
}


/**
 * Handles the back arrow click to switch views on smaller screens.
 */
function handleBackArrowClick() {
    if (window.innerWidth <= 780) {
        toggleElementVisibility('.contact-list', true);
        toggleElementVisibility('.contact', false);
    }
    toggleElementVisibility('#dots-icon', false);
    toggleElementVisibility('#add-contact-icon', true);
}


/**
 * Groups contacts by their first letter.
 * @param {Array} contacts - Array of contact objects.
 * @returns {Object} - Grouped contacts by first letter.
 */
function groupContactsByFirstLetter(contacts) {
    return contacts.reduce((groups, contact) => {
        const firstLetter = contact.name.charAt(0).toUpperCase();
        if (!groups[firstLetter]) {
            groups[firstLetter] = [];
        }
        groups[firstLetter].push(contact);
        return groups;
    }, {});
}


/**
 * Attaches click listeners to the contact items.
 */
function attachContactClickListeners() {
    contacts.forEach(contact => {
        let contactElement = document.querySelector(`.contact-item[data-id="${contact.id}"]`);
        if (contactElement) {
            contactElement.addEventListener('click', () => {
                showContactDetails(contact.id);
            });
        } else {
            console.warn(`Failed to attach event listener to contact with ID: ${contact.id}`);
        }
    });
}