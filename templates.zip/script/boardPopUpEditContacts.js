/**
 * Syncs contact icons in the overlay with the task details.
 * @param {Array} contactIds - An array of contact IDs.
 * @returns {Promise<void>}
 */
async function syncContactIcons(contactIds) {
    if (!contactIds || contactIds.length === 0) {
        return;
    }

    if (typeof contactIds[0] === 'object') {
        contactIds = contactIds.map(contact => contact.id || contact.name);
    }

    try {
        let response = await fetch('https://join-382-default-rtdb.europe-west1.firebasedatabase.app/contacts.json');
        let contactsData = await response.json();

        if (contactsData) {
            let contacts = Object.keys(contactsData).map(key => ({
                id: key,
                ...contactsData[key],
            }));

            let assignedContacts = contacts.filter(contact => contactIds.includes(contact.id) || contactIds.includes(contact.name));

            let contactIconsContainer = document.getElementById('contact-icons-container');
            if (contactIconsContainer) {
                contactIconsContainer.innerHTML = assignedContacts
                    .map(contact => {
                        let initials = contact.name.split(' ').map(word => word.charAt(0).toUpperCase()).join('');
                        let bgColor = contact.color || getRandomColor();
                        return `
                            <div class="contact-icon" style="background-color: ${bgColor};">
                                ${initials}
                            </div>
                        `;
                    })
                    .join('');
            }
        } else {
            console.error("Failed to fetch contacts from Firebase.");
        }
    } catch (error) {
        console.error("Error fetching contacts:", error);
    }
}


/**
 * Updates the dropdown with all contacts for the add task view.
 * @param {Array} allContacts - Array of all contact objects.
 * @param {Array} selectedContacts - Array of selected contact IDs.
 */
function updateContactDropdown(allContacts, selectedContacts) {
    let dropdownContainer = document.getElementById('assignTaskDropdown');
    if (!dropdownContainer) {
        console.error("Dropdown container 'assignTaskDropdown' not found.");
        return;
    }

    dropdownContainer.innerHTML = allContacts
        .map(contact => `
            <label>
                <input type="checkbox" data-id="${contact.id}" ${selectedContacts.includes(contact.id) ? 'checked' : ''}>
                ${contact.name}
            </label>
        `)
        .join('');
}

/**
 * Updates the contact icons displayed in the assign task section.
 * @param {Array<Object>} selectedContacts - Array of contact objects with name and color.
 */
function updateContactIcons(selectedContacts) {
    let iconsContainer = document.getElementById('contact-icons-container');
    if (!iconsContainer) {
        console.error("Icons container 'contact-icons-container' not found.");
        return;
    }

    iconsContainer.innerHTML = selectedContacts
        .map(contact => `
            <div class="contact-icon" style="background-color: ${contact.color || getRandomColor()};">
                ${contact.name.split(' ').map(word => word[0].toUpperCase()).join('')}
            </div>
        `)
        .join('');
}