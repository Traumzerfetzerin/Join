let selectedContacts = [];


/**
 * Fetches all contacts and generates the contact dropdown for addTask.
 * @returns {Promise<void>}
 */
async function initializeAddTaskDropdown() {
    try {
        let response = await fetch('https://join-382-default-rtdb.europe-west1.firebasedatabase.app/contacts.json');
        let contactsData = await response.json();

        if (contactsData) {
            let allContacts = Object.keys(contactsData).map(key => ({ id: key, ...contactsData[key] }));
            let dropdownHTML = generateContactDropdownHTML(allContacts, [], []);

            let dropdownContainer = document.getElementById('assignTaskDropdown');
            if (dropdownContainer) {
                dropdownContainer.innerHTML = dropdownHTML;
                console.log("Dropdown initialized successfully.");
            } else {
                console.error("Dropdown container 'assignTaskDropdown' not found in DOM.");
            }
        } else {
            console.error("No contacts data available for addTask.");
        }
    } catch (error) {
        console.error("Error fetching contacts:", error);
    }
}


/**
 * Generates initials from a contact's name.
 * 
 * @param {string} name - The name of the contact.
 * @returns {string} The initials derived from the name.
 */
function generateInitials(name) {
    return name
        .split(' ')
        .map(word => word.charAt(0).toUpperCase())
        .join('');
}


/**
 * Sets the background color for the initials span element.
 * 
 * @param {HTMLElement} initialsSpan - The span element displaying the initials.
 * @param {Object} contact - The contact object containing the color property.
 */
function setInitialsBackgroundColor(initialsSpan, contact) {
    if (contact.color) {
        initialsSpan.style.backgroundColor = contact.color;
    } else {
        let randomColor = getRandomColor();
        initialsSpan.style.backgroundColor = randomColor;
        contact.color = randomColor;
    }
}


/**
 * Generates a div element with the specified class.
 * @param {string} className - The class name to assign to the div.
 * @returns {HTMLElement} The created div element.
 */
function generateDiv(className) {
    let div = document.createElement('div');
    div.classList.add(className);
    return div;
}


/**
 * Updates the 'assigned-to' input field with a comma-separated list of selected contact names.
 * @returns {void}
 */
function updateAssignedContacts() {
    try {
        let selectedContacts = Array.from(
            document.querySelectorAll('#assignTaskDropdown .dropdown-container input[type="checkbox"]:checked')
        ).map(checkbox => checkbox.value);

        let input = document.getElementById('assigned-to');
        if (input) {
            input.value = selectedContacts.join(', ');
        } else {
            console.error("Input field 'assigned-to' not found in DOM.");
        }
    } catch (error) {
        console.error("Error updating assigned contacts:", error);
    }
}


/**
 * Toggles the visibility of the task assignment dropdown and additional icons.
 * @returns {void}
 */
function toggleDropdown() {
    try {
        let dropdown = document.getElementById('assignTaskDropdown');
        let vanishIcons = document.getElementById('contact-icons-container');

        if (dropdown) {
            dropdown.classList.toggle('dNone');
        } else {
            console.error("Dropdown container 'assignTaskDropdown' not found in DOM.");
        }

        if (vanishIcons) {
            vanishIcons.classList.toggle('dNone');
        } else {
            console.error("Icons container 'contact-icons-container' not found in DOM.");
        }
    } catch (error) {
        console.error("Error toggling dropdown:", error);
    }
}


/**
 * Closes the task assignment dropdown when clicking outside the input container.
 * @param {Event} event - The click event.
 * @returns {void}
 */
document.addEventListener('click', function (event) {
    try {
        let dropdown = document.getElementById('assignTaskDropdown');
        let vanishIcons = document.getElementById('contact-icons-container');
        let inputContainer = document.querySelector('.input-with-icon');

        if (dropdown && vanishIcons && inputContainer && !inputContainer.contains(event.target)) {
            dropdown.classList.add('dNone');
            vanishIcons.classList.add('dNone');
        } else if (!inputContainer) {
            console.error("Input container '.input-with-icon' not found in DOM.");
        }
    } catch (error) {
        console.error("Error handling click event for dropdown:", error);
    }
});


/**
 * Validates the form fields before task submission.
 * @returns {boolean} True if all required fields are valid, otherwise false.
 */
function validateTaskForm() {
    let contacts = collectContactIDs();
    if (!contacts.length) {
        console.error("No contacts selected.");
        return false;
    }

    // Add further validation logic if needed
    return true;
}
